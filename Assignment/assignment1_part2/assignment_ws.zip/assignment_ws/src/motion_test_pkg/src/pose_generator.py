#! /usr/bin/env python3
import random
import numpy as np

fixed_z = 0.7 # Fixed height to table
reach = 0.7 # A good guess
workspace_bounds = {'x_min': -2*reach, 'x_max': 2*reach}
robot_base_size = 0.33
base_box_size = 0.1
top_box_size = 0.05

def get_y(x):
    x1 = abs(x)
    if x1 > 0.7:
        return np.sqrt(abs(reach**2 - (x1-0.7)**2))
    elif x1 < 0.7:
        return np.sqrt(abs(reach**2 - (0.7-x1)**2))
    else:
        return 0.7

def not_in_collision(pose, box_size):
    x_min, x_max = 0.7 - robot_base_size/2 - box_size/2, 0.7 + robot_base_size/2 + box_size/2
    y_max = robot_base_size/2 + box_size/2

    if abs(pose[0]) <= x_max and abs(pose[0]) >= x_min:
        if abs(pose[1]) <= y_max:
            return False
        else:
            return True

def is_valid_base_pose(pose):
    if len(pose) == 0:
        return False
    else:
        return not_in_collision(pose, base_box_size)

def is_valid_top_pose(top_pose, base_pose):
    if len(top_pose) == 0:
        return False
    else:
        if not_in_collision(top_pose, top_box_size):
            x_top, y_top = top_pose[0], top_pose[1]
            x_base, y_base = base_pose[0], base_pose[1]
            a = base_box_size/2 + top_box_size/2 
            if x_top > x_base + a or x_top < x_base - a and y_top > y_base + a or y_top < y_base - a:
                return True
            else:
                return False
        else:
            return False

def get_random_poses():
    base_pose = ()
    top_pose = ()

    while not is_valid_base_pose(base_pose):
        x = random.uniform(workspace_bounds['x_min'], workspace_bounds['x_max'])
        positive_y = get_y(x)
        y = random.choice([positive_y, -positive_y])
        base_pose = (x,y,fixed_z)

    while not is_valid_top_pose(top_pose, base_pose):
        x = random.uniform(workspace_bounds['x_min'], workspace_bounds['x_max'])
        positive_y = get_y(x)
        y = random.choice([positive_y, -positive_y])
        top_pose = (x,y,fixed_z)

    return base_pose, top_pose