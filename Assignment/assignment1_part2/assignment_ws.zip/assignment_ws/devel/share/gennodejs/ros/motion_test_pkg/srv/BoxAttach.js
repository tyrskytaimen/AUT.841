// Auto-generated. Do not edit!

// (in-package motion_test_pkg.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class BoxAttachRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.robot_name = null;
      this.box_name = null;
      this.attach = null;
    }
    else {
      if (initObj.hasOwnProperty('robot_name')) {
        this.robot_name = initObj.robot_name
      }
      else {
        this.robot_name = '';
      }
      if (initObj.hasOwnProperty('box_name')) {
        this.box_name = initObj.box_name
      }
      else {
        this.box_name = '';
      }
      if (initObj.hasOwnProperty('attach')) {
        this.attach = initObj.attach
      }
      else {
        this.attach = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BoxAttachRequest
    // Serialize message field [robot_name]
    bufferOffset = _serializer.string(obj.robot_name, buffer, bufferOffset);
    // Serialize message field [box_name]
    bufferOffset = _serializer.string(obj.box_name, buffer, bufferOffset);
    // Serialize message field [attach]
    bufferOffset = _serializer.bool(obj.attach, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BoxAttachRequest
    let len;
    let data = new BoxAttachRequest(null);
    // Deserialize message field [robot_name]
    data.robot_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [box_name]
    data.box_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [attach]
    data.attach = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.robot_name);
    length += _getByteLength(object.box_name);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'motion_test_pkg/BoxAttachRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ccee674e3c258b347ad6f905b2661fbd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string robot_name #Must be: 'robot1' or 'robot2'
    string box_name
    bool attach #True to attach, False to release
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BoxAttachRequest(null);
    if (msg.robot_name !== undefined) {
      resolved.robot_name = msg.robot_name;
    }
    else {
      resolved.robot_name = ''
    }

    if (msg.box_name !== undefined) {
      resolved.box_name = msg.box_name;
    }
    else {
      resolved.box_name = ''
    }

    if (msg.attach !== undefined) {
      resolved.attach = msg.attach;
    }
    else {
      resolved.attach = false
    }

    return resolved;
    }
};

class BoxAttachResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.message = null;
      this.success = null;
    }
    else {
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BoxAttachResponse
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BoxAttachResponse
    let len;
    let data = new BoxAttachResponse(null);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'motion_test_pkg/BoxAttachResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9bf829f07d795d3f9e541a07897da2c4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string message
    bool success
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BoxAttachResponse(null);
    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: BoxAttachRequest,
  Response: BoxAttachResponse,
  md5sum() { return 'ebddcd5f39e352dc4621432b68da2285'; },
  datatype() { return 'motion_test_pkg/BoxAttach'; }
};
