#! /usr/bin/env python3
import sys
import rospy
import time
import copy
import PyKDL 
import tf
import math
import numpy as np
import moveit_commander
import moveit_msgs.msg
from motion_test_pkg.srv import *
from geometry_msgs.msg import Pose
from geometry_msgs.msg import PoseStamped

rospy.init_node('motion_control_node', anonymous=True)

#MODIFY DEPENDING ON THE NAME OF THE LINKS OF YOUR ROBOT
eef_links = ["robot1_gripper_base_link", "robot2_gripper_base_link"]
touch_links = [["robot1_gripper1_finger_left, robot1_gripper1_finger_right"],["robot2_gripper2_finger_left, robot2_gripper2_finger_right"]]

#Initializes moveit_commander
moveit_commander.roscpp_initialize(sys.argv) 
robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
arm1 = moveit_commander.MoveGroupCommander("arm1")
arm2 = moveit_commander.MoveGroupCommander("arm2")
gripper1 = moveit_commander.MoveGroupCommander("gripper1")
gripper2 = moveit_commander.MoveGroupCommander("gripper2")

arm1.clear_pose_targets()
arm2.clear_pose_targets()
gripper1.clear_pose_targets()
gripper2.clear_pose_targets()

#Get random positions
service_name = '/random_pose_service'
rospy.wait_for_service(service_name)
random_pose_service = rospy.ServiceProxy(service_name, PoseGenerator)
servResult = random_pose_service()
base = servResult.base_pose
top = servResult.top_pose
if servResult.success:
    print(servResult)
else:
    print("ERROR")

#Spawn the box
rospy.wait_for_service('/scene_spawner/spawn_box')
rospy.wait_for_service('/scene_spawner/attach_release_box')
box_service = rospy.ServiceProxy('/scene_spawner/spawn_box', BoxSpawner)
attach_service = rospy.ServiceProxy('/scene_spawner/attach_release_box', BoxAttach)
baseReq = BoxSpawnerRequest(base.position.x, base.position.y, base.position.z, 'base', True)
topReq = BoxSpawnerRequest(top.position.x, top.position.y, top.position.z, 'top', False)
baseRes = box_service(baseReq)
topRes = box_service(topReq)

#Functions for poses conversion
def frame_to_pose(frame):
	pose_result = Pose()
	pose_result.position.x = frame.p[0] 
	pose_result.position.y = frame.p[1] 
	pose_result.position.z = frame.p[2] 
	ang = frame.M.GetQuaternion() 
	pose_result.orientation.x = ang[0] 
	pose_result.orientation.y = ang[1] 
	pose_result.orientation.z = ang[2] 
	pose_result.orientation.w = ang[3]
	return pose_result

def get_goal_pose(pose, offset):
	#End Effector goal frame
	EEF_frame = PyKDL.Frame()
	EEF_frame.p = PyKDL.Vector(pose.position.x, pose.position.y, pose.position.z+offset)
	gripper_length = 0.22

	#Transform End Effector frame to the goal_frame for the last joint of the arm
	goal_frame = copy.deepcopy(EEF_frame)
	goal_frame.p[2] += gripper_length #Convert from gripper to wrist frame
	goal_frame.M.DoRotX(3.14) #Gripper pointing down

	#Defines the PoseStamped that is the goal
	goal_pose = frame_to_pose(goal_frame)
	pose_stamped_target_wrist = PoseStamped()
	pose_stamped_target_wrist.header.frame_id = "gripper1_base_link"
	pose_stamped_target_wrist.header.stamp = rospy.get_rostime()
	pose_stamped_target_wrist.pose = goal_pose
    
	return pose_stamped_target_wrist.pose

# Function to move to top box
def move_to_top_box(arm, gripper, robot, pose=top):    
    pose_stamped_target_wrist = get_goal_pose(pose, 0.05)

    gripper.set_named_target('open')
    gripper.go(wait=True)
    time.sleep(0.5)

    print(robot, " is moving to top box")
    arm.set_pose_target(pose_stamped_target_wrist)
    arm.go(wait=True)
    time.sleep(0.5)

    gripper.set_named_target('grasp')
    gripper.go(wait=True)
    time.sleep(0.5)

    graspReq = BoxAttachRequest(robot, 'top', True)
    result = attach_service(graspReq)

# Function to move to base box
def move_to_base_box(arm, gripper, robot):    
    pose_stamped_target_wrist = get_goal_pose(base, 0.1)

    print(robot, " is moving to base box")
    arm.set_pose_target(pose_stamped_target_wrist)
    arm.go(wait=True)
    time.sleep(0.5)

    gripper.set_named_target('open')
    gripper.go(wait=True)
    time.sleep(0.5)

    graspReq = BoxAttachRequest(robot, 'top', False)
    result = attach_service(graspReq)

    print(robot, " is moving home")
    arm.set_named_target('home')
    arm.go(wait=True)
    time.sleep(0.5)

    gripper.set_named_target('grasp')
    gripper.go(wait=True)
    time.sleep(0.5)

center = Pose()
center.position.x = 0
center.position.y = 0
center.position.z = 0.7

def move_to_center_box(arm, gripper, robot):
    pose_stamped_target_wrist = get_goal_pose(center, 0.05)

    print(robot, " is moving to center")
    arm.set_pose_target(pose_stamped_target_wrist)
    arm.go(wait=True)
    time.sleep(0.5)

    gripper.set_named_target('open')
    gripper.go(wait=True)
    time.sleep(0.5)

    graspReq = BoxAttachRequest(robot, 'top', False)
    result = attach_service(graspReq)

    print(robot, " is moving home")
    arm.set_named_target('home')
    arm.go(wait=True)
    time.sleep(0.5)
     

if top.position.x >0:
    move_to_top_box(arm1, gripper1, 'robot1')
    if base.position.x > 0:
        move_to_base_box(arm1, gripper1, 'robot1')
    else:
        move_to_center_box(arm1, gripper1, 'robot1')
        move_to_top_box(arm2, gripper2, 'robot2', center)
        move_to_base_box(arm2, gripper2, 'robot2')
         
elif top.position.x < 0:
    move_to_top_box(arm2, gripper2, 'robot2')
    if base.position.x < 0:
        move_to_base_box(arm2, gripper2, 'robot2')
    else:
        move_to_center_box(arm2, gripper2, 'robot2')
        move_to_top_box(arm1, gripper1, 'robot1', center)
        move_to_base_box(arm1, gripper1, 'robot1')

print("End")
rospy.spin()