#! /usr/bin/env python3
import sys
import rospy
from motion_test_pkg.srv import PoseGenerator, PoseGeneratorResponse
from pose_generator import get_random_poses
from geometry_msgs.msg import Pose

rospy.init_node('random_pose_generator_node', anonymous=True)
service_name = '/random_pose_service'

def service_callback(req):
    """
    """
    print("Received request for poses")
    resp = PoseGeneratorResponse()

    try:
        base_pose, top_pose = get_random_poses()

        random_base_pose = Pose()
        random_base_pose.position.x = base_pose[0]
        random_base_pose.position.y = base_pose[1]
        random_base_pose.position.z = base_pose[2]
        random_base_pose.orientation.w = 1

        random_top_pose = Pose()
        random_top_pose.position.x = top_pose[0]
        random_top_pose.position.y = top_pose[1]
        random_top_pose.position.z = top_pose[2]
        random_top_pose.orientation.w = 1

        resp.base_pose = random_base_pose
        resp.top_pose = random_top_pose
        resp.success = True
        return resp
    except:
        resp.success = False
        return resp
    
rospy.Service(service_name, PoseGenerator, service_callback)
rospy.spin()
