
"use strict";

let BoxSpawner = require('./BoxSpawner.js')
let BoxAttach = require('./BoxAttach.js')
let PoseGenerator = require('./PoseGenerator.js')

module.exports = {
  BoxSpawner: BoxSpawner,
  BoxAttach: BoxAttach,
  PoseGenerator: PoseGenerator,
};
